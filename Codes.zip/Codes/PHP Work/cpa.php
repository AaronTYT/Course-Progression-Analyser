<?php
    $errorCode = 0;
    $varRowCounts = 0;

    //Classes:
    class Unit{
        public $unitC;
        public $credit;
        public $year;
        public $mark;
    }

    class studentProgress{
        public $pass = 0;
        public $attempt = 0;
        public $fail = 0;
        public $courseType;
        public $creditRequired;
    }
    //Lists
    $listUnits = array();
    $studentData = array();
    $unitGrades = array();

    $totalCredits = array();

    $totalCreditsPassed = array();

    $points = array();

    function studentSummary(){
        echo "<h1>Results:</h1>";
        echo "<hr>";

        //Student Details:
        echo "<h2>Student details: </h2>";
        echo "<strong>First Name: </strong>".$_POST['Firstname']."<br>";
        echo "<strong>Last Name: </strong>".$_POST['Surname']."<br>";
        echo "<strong>Student ID: </strong>".$_POST['StudentID']."<br>";

        //Student Progress:
        echo "<h2>Student course progression: </h2>";
        displayStudentData();
    }

    //Validation function to check all inputs are valid (errorCode = 0)
	function validation(){
        $errorCode = 0;
        $firstName = $_POST["Firstname"];
        $lastName = $_POST["Surname"];

        if(!ctype_alpha($firstName)){
            echo "Employee first name should have only letters.<br>";
            $errorCode = 1;
        }

        if(!ctype_alpha($lastName)){
            echo "Employee last name should have only letters.<br>";
            $errorCode = 1;
        }

        if(!is_numeric($_POST["StudentID"]) or strlen($_POST["StudentID"]) < 8){
            echo "Student ID should only be numbers. Enter a 8 digit student ID.</br>";
            $errorCode = 1;
        }

        if($errorCode == 1){
            return $errorCode;
        }
        $missingRowData = 0;

        $varFieldCounts = 0;

        //Counts all the fields in a form (including submit button)
        foreach ($_POST as $key => $val)
        {
            $varFieldCounts += 1;
        }

        $varFieldCounts -= 5;
        $GLOBALS['varRowCounts'] = $varFieldCounts / 4;

        for($i = 1; $i <= $GLOBALS['varRowCounts']; $i++){

            $credit = $_POST["CP_".$i];
            $unitMark = $_POST["UM_".$i];
            $unitCode = $_POST["UnitCode_".$i];
            $year = $_POST["YS_".$i];

            if($credit == "" and $unitMark == "" and $unitCode == "" and $year == ""){
                $missingRowData += 1;

                //If the user has not put at least one row of data.
                if($missingRowData == $GLOBALS['varRowCounts']){
                    echo "You need to enter at least 1 row of data <br>";
                    echo "Go back to the form and enter the unit data at least one row <br>";
                    $errorCode = 1;
                }
                continue;
            }

            //If the user has at least put data in a row of any field.
            if(strlen($credit) >= 0 or strlen($unitMark) >= 0 or strlen($unitCode) >= 0 or strlen($year) >= 0){

                if($credit == ""){
                    echo "Row #".$i.", missing credit <br>";
                    $errorCode = 1;
                }

                if($unitMark == ""){
                    echo "Row #".$i.", missing unitMark <br>";
                    $errorCode = 1;
                }

                if($unitCode == ""){
                    echo "Row #".$i.", missing unitCode <br>";
                    $errorCode = 1;
                }

                if($year == ""){
                    echo "Row #".$i.", missing year <br>";
                    $errorCode = 1;
                }

            }
        }
        if($errorCode == 1){
            return $errorCode;
        }

        for($i = 1; $i <= $GLOBALS['varRowCounts']; $i++){
            $aunit = new Unit;
            $credit = $_POST["CP_".$i];
            $unitMark = $_POST["UM_".$i];
            $unitCode = $_POST["UnitCode_".$i];
            $year = $_POST["YS_".$i];

            //If the row has no field inputs, move on to the next row.
            if($credit == "" and $unitMark == "" and $unitCode == "" and $year == ""){
                continue;
            }

            //Special characters should not be allowed and cannot be less then 7 characters long.
            if(strlen($unitCode) < 7 or !ctype_alnum($unitCode)){
                echo "Row #".$i.", the unitCode should be 7 characters long and no special characters <br>";
                $errorCode = 1;
            }else{
                $aunit->unitC = $unitCode;
            }

            if(!is_numeric($_POST["CP_".$i]) or $credit != 15 and $credit != 20){
                echo "Row #".$i.", the credit should be either 15 or 20 <br>";
                $errorCode = 1;
            }else{
                $aunit->credit = $credit;
            }

            if(!is_numeric($_POST["UM_".$i]) or $unitMark < 0 or $unitMark > 100){
                echo "Row #".$i.", the mark should be between 0 to 100 <br>";
                $errorCode = 1;
            }else{
                $aunit->mark = $unitMark;
            }

            if(!is_numeric($_POST["YS_".$i]) or strlen($year) < 3){
                echo "Row #".$i.", the year length should be 3 digits long <br>";
                $errorCode = 1;
            }else{
                $aunit->year = $year;
            }

            array_push($GLOBALS['listUnits'], $aunit);
        }
        return $errorCode;
    }

function addData($a, $aStudent, $unitGrade){
    array_push($GLOBALS['points'], $a->mark * $a->credit);
    array_push($GLOBALS['totalCreditsPassed'], $a->credit);

    if ($aStudent->fail != 0) {
        $aStudent->fail -= 1;
    }
    $aStudent->pass += 1;
    array_push($GLOBALS['unitGrades'], $unitGrade);
    array_push($GLOBALS['totalCredits'], $a->credit);
}


function displayStudentData(){
    $aStudent = new studentProgress;

    if($_POST["CourseType"] == 1){
        $aStudent->courseType = "Undergraduate";
        $aStudent->creditRequired = 360;
    }
    else if($_POST["CourseType"] == 2){
        $aStudent->courseType = "Graduate Diploma";
        $aStudent->creditRequired = 120;
    }
    else if($_POST["CourseType"] == 3){
        $aStudent->courseType = "Masters by Coursework";
        $aStudent->creditRequired = 180;
    }else{
        $aStudent->courseType = "Masters by Research";
        $aStudent->creditRequired = 240;
    }

    $listUnits = $GLOBALS['listUnits'];
    foreach($listUnits as $a) {
        $unitGrade = calculateGrade($a->mark);

        //If a student failed his or her unit, add a fail score.
        if($a->mark < 50) {

            if(array_sum($GLOBALS['totalCredits']) >= ($aStudent->creditRequired * 0.66)) {
                if ($a->mark >= 46 && $a->mark <= 49) {
                    $unitGrade = "Conceded Pass";
                    addData($a, $aStudent, $unitGrade);

                }

                else if ($a->mark >= 40 && $a->mark <= 45) {
                    $unitGrade = "Supp assessment";
                    addData($a, $aStudent, $unitGrade);
                }

                else{
                    $aStudent->fail += 1;
                    array_push($GLOBALS['points'], $a->mark * $a->credit);
                    array_push($GLOBALS['totalCredits'], $a->credit);
                    array_push($GLOBALS['unitGrades'], $unitGrade);
                }
            }else {
                $aStudent->fail += 1;
                array_push($GLOBALS['points'], $a->mark * $a->credit);
                array_push($GLOBALS['totalCredits'], $a->credit);
                array_push($GLOBALS['unitGrades'], $unitGrade);
                $aStudent->attempt += 1;
                continue;
            }

        }else{

            $aStudent->pass += 1;
            array_push($GLOBALS['totalCredits'], $a->credit);
            array_push($GLOBALS['totalCreditsPassed'], $a->credit);
            array_push($GLOBALS['points'], $a->mark * $a->credit);
            array_push($GLOBALS['unitGrades'], $unitGrade);
        }
        $aStudent->attempt += 1;
    }

    echo "Course Type: ".$aStudent->courseType.". Course passing credits require: ".$aStudent->creditRequired." points <br>";

    if(checkFails() == true){
        echo "Course Excluded!<br>";
    }else if(array_sum($GLOBALS['totalCreditsPassed']) >= $aStudent->creditRequired){
        echo "Course Completed!<br>";
    }else{
        echo "Degree credits to pass: "."<strong>".($aStudent->creditRequired - array_sum($GLOBALS['totalCreditsPassed']))."</strong> points left<br>";
    }

    echo "Units attempted: ".$aStudent->attempt." times <br>";
    echo "Units attempted successfully: ".$aStudent->pass." times <br>";


    $WAM = array_sum($GLOBALS['points'])/array_sum($GLOBALS['totalCredits']);
    $grade = calculateGrade($WAM);
    echo "Course Weighted Average (WAM): <strong>".round($WAM, 2)." (".$grade.")</strong><br>";

    array_push($GLOBALS['studentData'], $aStudent);
}
function checkFails(){
    $n = 0;
    foreach($GLOBALS['unitGrades'] as $eachN){
        if($eachN == "N"){
            $n += 1;
        }

        if($n == 3){
            return true;
        }
    }
    return false;
}

function calculateGrade($mark){
    if($mark < 50){
        return "N";
    }else if($mark < 60){
        return "C";
    }else if($mark < 70){
        return "CR";
    }else if($mark < 80){
        return "D";
    }else{
        return "HD";
    }
}
	
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8" />
    <title>Student Progress</title>
</head>
	<body>

	<?php
		//Start main program

		$errorCode = validation();
		if($errorCode == 1){
			echo "Please go back to the course form and fix the following mistakes shown above</br>";
			exit();
		}else{
		    studentSummary();
        }
		

	?>

    <h2>Unit Results: </h2>
    <table border="1">
        <tr>
            <td>Unit Code</td>
            <td>Credit Points</td>
            <td>Year/Semester</td>
            <td>Mark (/100)</td>
            <td>Grade</td>
        </tr>

        <?php
            $a = 1;

            for($i = 1; $i <= $GLOBALS['varRowCounts']; $i++) {

                //If the row is fully empty without any inputs, add $a count to 1 and move on to the next row.
                if ($_POST["UnitCode_".$i] == "" && $_POST["CP_".$i] == "" && $_POST["YS_".$i] == "" && $_POST["UM_".$i] == "") {
                    $a += 1;
                    continue;
                }
                ?>

                <!-- UnitCode field output -->
                <tr>
                    <?php
                        $unitCode = $_POST['UnitCode_'.$i];
                        if($unitCode != ""){
                            ?>
                            <td>
                                <?php echo $unitCode; ?>
                            </td>
                        <?php
                        }
                        ?>

                    <!-- credit field output -->
                    <?php
                    $credit = $_POST['CP_'.$i];
                    if($credit != "") {
                        ?>
                        <td>
                            <?php echo $_POST["CP_".$i]; ?>

                        </td>
                        <?php
                    }
                    ?>

                    <!-- year/semester field output -->
                    <?php
                    $year = $_POST['YS_'.$i];
                    if($year != "") {
                        ?>
                        <td>
                            <?php echo $_POST["YS_".$i]; ?>

                        </td>
                        <?php
                    }
                    ?>

                    <!-- mark field output -->
                    <?php
                    $mark = $_POST['UM_'.$i];
                    if($mark != "") {
                        ?>
                        <td>
                            <?php echo $_POST["UM_".$i]; ?>

                        </td>
                        <?php
                    }
                    ?>

                    <!-- Display the Grade -->
                    <?php
                        if($mark != ""){
                    ?>
                    <td>
                        <?php echo $GLOBALS['unitGrades'][$i-$a] ?>

                    </td>
                <?php
                        }
                    ?>
                </tr>

            <!-- End for loop and end program -->
            <?php
            }
            ?>
    </table>
	</body>
</html>